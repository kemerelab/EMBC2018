Jill Juneau
Rice University
903-922-0331
jcj3@rice.edu

Files
.apr		Aperature File
.G1		Midlayer 1 (GND)
.G2		Midlayer 2 (PWR)
.GBL		Bottom Layer
.GBO		Bottom Overlay
.GBP		Bottom Paste Mask
.GBS		Bottom Solder Mask
.GD1		Drill Drawing Layer Pair
.GG1		Drill Guide Layer Pair
.GM1		Mechanical Layer - Board Outline	
.GTL		Top Layer
.GTO		Top Overlay
.GTP		Top Paste Mask
.GTS 		Top Solder Mask
.DRR		NC Drill
